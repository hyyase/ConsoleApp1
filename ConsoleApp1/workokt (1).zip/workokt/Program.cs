// === Funcionários ===
var dev     = new Desenvolvedor("Arthur", "DEV001", "C#");
var analista = new Analista("Maria", "ANA001");
var devOps  = new DevOps("Carlos", "DEVOPS001");
var help    = new HelpDesks("João", "HELP001");

// deixa a Maria inativa
analista.Ativo = false;

// === Perfis ===
Console.WriteLine("=== Exibindo Perfis ===\n");
dev.ExibirInformacoes();
analista.ExibirInformacoes();
devOps.ExibirInformacoes();
help.ExibirInformacoes();

// === Catraca ===
Console.WriteLine("\n=== Registros de Acesso ===\n");
var catraca = new Catraca();

catraca.RegistrarEntrada(dev);
catraca.RegistrarEntrada(analista); // negado
catraca.RegistrarEntrada(devOps);
catraca.RegistrarEntrada(help);
catraca.RegistrarSaida(dev);

// === Permissões ===
Console.WriteLine("\n=== Permissões ===\n");
catraca.DefinirPermissao(dev);
catraca.DefinirPermissao(devOps);

var permissao = catraca.ObterPermissao(dev);
Console.WriteLine($"{dev.Nome} (expression) — permissão: {permissao}.");

// === Histórico ===
catraca.ExibirHistorico();

// === Filtros ===
Console.WriteLine("\n=== Funcionários Ativos ===\n");
var lista = new List<Funcionario> { dev, analista, devOps, help };
var filtro = new FiltroFuncionario(lista);

foreach (var f in filtro.Ativos())
    Console.WriteLine($"{f.Nome} ({f.Cargo})");

Console.WriteLine("\n=== Só Desenvolvedores ===\n");
foreach (var f in filtro.PorCargo(Cargo.Desenvolvedor))
    Console.WriteLine($"{f.Nome} ({f.Cargo})");
